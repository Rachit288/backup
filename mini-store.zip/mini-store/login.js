document.querySelector("form").addEventListener("submit", function(event){
    event.preventDefault();
    let name = document.getElementById("name").value;
    let email = document.getElementById("email").value;
    let phone = document.getElementById("phone").value;
    let password = document.getElementById("password").value;
    let confirmPassword = document.getElementById("confirmPassword").value;
    let terms = document.getElementById("terms").checked;

    if(!email.includes("@")){
        alert("email must contain @");
    } else if(!/^\d{10}$/.test(phone)){
        alert("phone number only contains 10 digits");
    } else if(password.length < 6){
        alert("password must contain 6 characters");
    } else if(password !== confirmPassword){
        alert("password not matching");
    } else if(!terms){
        alert("please agree to terms and conditions");
    } else{
        localStorage.setItem("name", name);
        localStorage.setItem("email", email);
        alert("done");
    }
});