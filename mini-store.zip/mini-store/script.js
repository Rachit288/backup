let count = Number(localStorage.getItem("cartCount")) || 0;
document.getElementById("cart").textContent = "cart: " + count;
function addToCart(){
    count++;
    document.getElementById("cart").innerHTML = "cart: " + count;
    localStorage.setItem("cartCount", count);
}

document.getElementById("locationBtn").addEventListener("click", function(){
    navigator.geolocation.getCurrentPosition(
        function(position){
            document.getElementById("locationResult").textContent =
                "latitude: " + position.coords.latitude +
                ", longitude: " + position.coords.longitude;
        },
        function(){
            document.getElementById("locationResult").textContent = 
                "unable to get location";
        }
    );
});

function drag(event){
    event.dataTransfer.setData("text", event.target.querySelector("h3, h5").textContent);
}
function allowDrop(event){
    event.preventDefault();
}
function drop(event){
    event.preventDefault();
    let product = event.dataTransfer.getData("text");
    alert(product + " added to cart!");
    addToCart();
}

function searchProducts(){
    let search = document.getElementById("search").value.toLowerCase();
    let cards = document.querySelectorAll("#products .card");
    cards.forEach(function(card){
        let name = card.querySelector("h3, h5").textContent.toLowerCase();
        card.parentElement.style.display = name.includes(search) ? "" : "none";
    });
}

function clearCart(){
    count = 0;
    document.getElementById("cart").textContent = "cart: 0";
    localStorage.setItem("cartCount", 0);
}