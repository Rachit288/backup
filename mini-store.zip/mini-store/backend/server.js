
const express = require("express");
const db = require("./db");

const app = express();

app.use(express.json());

// Home route
app.get("/", (req, res) => {
    res.send("Mini Store Backend is running!");
});

// Get all products
app.get("/products", (req, res) => {
    db.query("SELECT * FROM products", (err, results) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }

        res.json(results);
    });
});

// Add a product
app.post("/products", (req, res) => {
    const { name, price } = req.body;

    if (!name || price == null || price === "" || !Number.isFinite(Number(price)) || Number(price) <= 0) {
        return res.status(400).json({
            message: "Please provide a valid product name and price"
        });
    }

    const sql = "INSERT INTO products (name, price) VALUES (?, ?)";

    db.query(sql, [name, Number(price)], (err, result) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }

        res.status(201).json({
            message: "Product added successfully",
            product: {
                id: result.insertId,
                name: name,
                price: Number(price)
            }
        });
    });
});

// Update a product
app.put("/products/:id", (req, res) => {
    const id = Number(req.params.id);
    const { name, price } = req.body;

    if (!Number.isInteger(id) || id <= 0 || (name === undefined && price === undefined)) {
        return res.status(400).json({
            message: "Provide a valid ID and at least one field to update"
        });
    }

    if (
        (name !== undefined && (typeof name !== "string" || !name.trim())) ||
        (price !== undefined && (price === null || price === "" || !Number.isFinite(Number(price)) || Number(price) <= 0))
    ) {
        return res.status(400).json({
            message: "Please provide a valid product name and price"
        });
    }

    const sql = "UPDATE products SET name = COALESCE(?, name), price = COALESCE(?, price) WHERE id = ?";

    db.query(sql, [name === undefined ? null : name.trim(), price === undefined ? null : Number(price), id], (err, result) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }

        if (result.affectedRows === 0) {
            return res.status(404).json({
                message: "Product not found or no changes made"
            });
        }

        res.json({ message: "Product updated successfully" });
    });
});

// Delete a product
app.delete("/products/:id", (req, res) => {
    const id = Number(req.params.id);

    if (!Number.isInteger(id) || id <= 0) {
        return res.status(400).json({
            message: "Please provide a valid product ID"
        });
    }

    db.query("DELETE FROM products WHERE id = ?", [id], (err, result) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }

        if (result.affectedRows === 0) {
            return res.status(404).json({
                message: "Product not found"
            });
        }

        res.json({ message: "Product deleted successfully" });
    });
});

// Start the server
app.listen(3000, () => {
    console.log("Server running at http://localhost:3000");
});

//http://localhost:3000/products
//CREATE DATABASE mini_store;
//USE mini_store;
//CREATE TABLE products(
//id INT AUTO_INCREMENT PRIMARY KEY,
//name VARCHAR(100) NOT NULL,
//price DECIMAL(10,2) NOT NULL
// );
//USE mini_store;
//INSERT INTO products (name, price)
//VALUES
//('Laptop', 55000.00),
//('Mouse', 500.00),
//('Keyboard', 1200.00),
//('Headphones', 2000.00),
//('Monitor', 12000.00);
