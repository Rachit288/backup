// Practical 1: Node.js server-side JavaScript
console.log('Hello world');
