// Practical 10: MongoDB CRUD. Start MongoDB locally or set MONGODB_URI.
const { MongoClient } = require('mongodb');
async function main(){
  const client = new MongoClient(process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017');
  try {
    await client.connect();
    const collection = client.db('library_db').collection('books');
    const result = await collection.insertOne({title:'Demo Book',author:'Demo Author',isbn:'MONGO-DEMO-1',available:1});
    console.log('CREATE:',result.insertedId);
    console.log('READ:',await collection.findOne({_id:result.insertedId}));
    await collection.updateOne({_id:result.insertedId},{$set:{available:2}});
    console.log('UPDATE:',await collection.findOne({_id:result.insertedId}));
    await collection.deleteOne({_id:result.insertedId});
    console.log('DELETE: demo record removed');
  } finally { await client.close(); }
}
main().catch(e=>{console.error(e.message);process.exitCode=1;});
