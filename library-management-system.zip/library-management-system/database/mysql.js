// Node.js + MySQL CRUD demonstration. Set MYSQL_HOST, MYSQL_USER, MYSQL_PASSWORD in your environment.
const mysql = require('mysql2/promise');
async function main(){
  const db = await mysql.createConnection({host:process.env.MYSQL_HOST||'localhost',user:process.env.MYSQL_USER||'root',password:process.env.MYSQL_PASSWORD||'',database:process.env.MYSQL_DATABASE||'library_db'});
  try {
    const [insert] = await db.execute('INSERT INTO books(title,author,isbn,category,available) VALUES(?,?,?,?,?)',['Demo Book','Demo Author','DEMO-001','Practical Demo',1]);
    await db.execute('UPDATE books SET available=? WHERE id=?',[2,insert.insertId]);
    const [all] = await db.execute('SELECT * FROM books'); console.log('SELECT:',all);
    const [unique] = await db.execute('SELECT DISTINCT category FROM books'); console.log('SELECT DISTINCT:',unique);
    await db.execute('DELETE FROM books WHERE id=?',[insert.insertId]); console.log('Deleted demo record');
    // Table deletion demonstration, deliberately commented out to avoid data loss:
    // await db.execute('DROP TABLE books');
  } finally { await db.end(); }
}
main().catch(e=>{console.error(e.message);process.exitCode=1;});
