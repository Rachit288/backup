-- Practical 8: Run in MySQL Workbench or mysql CLI.
CREATE DATABASE IF NOT EXISTS library_db;
USE library_db;
CREATE TABLE IF NOT EXISTS books (
  id INT PRIMARY KEY AUTO_INCREMENT,
  title VARCHAR(150) NOT NULL,
  author VARCHAR(120) NOT NULL,
  isbn VARCHAR(30) NOT NULL UNIQUE,
  category VARCHAR(80),
  available INT NOT NULL DEFAULT 1
);
INSERT INTO books (title, author, isbn, category, available)
VALUES ('Clean Code','Robert C. Martin','9780132350884','Technology',3)
ON DUPLICATE KEY UPDATE available=VALUES(available);
UPDATE books SET available=4 WHERE isbn='9780132350884';
SELECT * FROM books;
SELECT DISTINCT category FROM books;
DELETE FROM books WHERE isbn='9780132350884';
-- Drop only when you have finished demonstrating the table:
-- DROP TABLE books;
