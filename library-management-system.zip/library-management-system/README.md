# Library Management System — Full Stack Development Practical Project

A single project covering the concepts listed in the Nirma University 3CS524CC26 Full Stack Development practical list. The default app uses a JSON file for persistence so it runs without database setup; separate MySQL and MongoDB exercises are included.

## Requirements
- Node.js 18 or newer
- Internet for Bootstrap/Vue/Tailwind CDN demos (Bootstrap offline mode can be demonstrated by downloading Bootstrap files and linking them locally)

## Run the main application
```bash
npm install
npm start
```
Open http://localhost:3000. The application stores the main records in `data/books.json`.

## Demo accounts
- `admin` / `Admin@123` — admin-only summary route
- `librarian` / `Librarian@123` — editor role
- `student` / `Student@123` — viewer role

These are classroom demo credentials, not production authentication. The demo login uses in-memory sessions and plaintext demo credentials to keep the practical easy to understand. For real deployment, use hashed passwords, secure persistent sessions, HTTPS, rate limiting, and environment-based secrets. The standalone `data/users.json` is a sample data file and is not used by the demo login endpoint.

## Practical map
1. `practicals/inline-javascript.html`, `script.js`, `app.js`: embedded JS, Node.js Hello World, write a JSON object to a file, app title.
2. `practical2-json.js`, `data/books.json`, dashboard reading tasks: JSON objects, external JSON, multidimensional arrays, add/complete/remove tasks.
3. `public/index.html` + `public/styles.css`: viewport meta tag and responsive layout. `practicals/responsive.html` demonstrates width/max-width, responsive images, `vw` text sizing, and media-query breakpoints.
4. Dashboard geolocation button, Local Storage reading tasks, `practicals/drag-drop.html`.
5. Bootstrap CDN is used in the main page and demos; `practicals/bootstrap-registration.html` contains roll number, first name, mobile, email and address fields. For offline Bootstrap, download Bootstrap 5 CSS/JS into `public/vendor/bootstrap/` and change the link to the local file. Registration form fields can be demonstrated by adapting the generic record form or adding student fields in `config/entities.js`.
6. `practicals/tailwind.html`.
7. `practicals/vue.html`: click-to-uppercase directive, dynamic list, human-readable date directive.
8. `database/mysql-practical.sql` and `database/mysql.js`: database/table creation, insert, update, select, distinct, delete, and drop-table demonstration (drop is commented out to prevent accidental data loss).
9. `/practicals/auth.html` and RBAC endpoints in `server.js`.
10. `database/mongodb.js`: MongoDB create/read/update/delete.
11. Git/GitHub and deployment instructions below.

## Topic switch with minimal edits
1. Edit `config/app.js` to change the app name.
2. Edit `config/entities.js`: set singular/plural entity names and define the new fields. Example Student fields: `rollNo`, `name`, `branch`, `email`, `semester`, `status`.
3. Update `data/books.json` with sample records whose keys match the new fields. The file name can stay the same to avoid changing code.
4. If the new topic uses a different unique field, change the `uniqueValue` check in `server.js` (currently checks `isbn`). The uniqueness field is configurable through `uniqueKey` in `config/entities.js`.
5. Change `database/mysql-practical.sql` and `database/mongodb.js` sample field names only if you need to demonstrate the database practical using the new domain.

The generic API and form/table rendering are driven by `config/entities.js`; do not hardcode new fields in the frontend.

## Git and GitHub
```bash
git init
git add .
git commit -m "Initial library management system"
# Create an empty GitHub repository, then use its URL:
git branch -M main
git remote add origin <YOUR_GITHUB_REPOSITORY_URL>
git push -u origin main
```

## Deployment
Deploy the Node.js application to a Node-capable platform. Set the start command to `npm start`. Note: the JSON file store is for local/practical demonstration; ephemeral hosting may reset file changes. Use MongoDB Atlas or a managed database for persistent deployed data. Do not commit secrets or production credentials.

## Important limitations for practical explanation
- The demo RBAC API is deliberately simplified for lab demonstration, not production security.
- The core app is JSON-file-backed; MySQL and MongoDB are shown in separate practical scripts so you can demonstrate each database without requiring both to run the dashboard.
- The Tailwind CDN page is for learning. For production, use Tailwind's build setup.
