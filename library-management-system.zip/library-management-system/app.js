// Practical 1: Create and store a JSON object in a file
const fs = require('fs');
const library = { name: 'Campus Library', location: 'Nirma University', open: true };
fs.writeFileSync('data/library-info.json', JSON.stringify(library, null, 2));
console.log('Saved library information to data/library-info.json');
