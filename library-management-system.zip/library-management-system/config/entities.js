// TOPIC SWITCH: To change the project topic, edit labels and fields here first.
// Example: for Student Management, change Books/Book to Students/Student and replace fields.
module.exports = {
  entityName: 'Book',
  uniqueKey: 'isbn',
  entityNamePlural: 'Books',
  fields: [
    { key: 'title', label: 'Title', type: 'text', required: true, placeholder: 'e.g. Clean Code' },
    { key: 'author', label: 'Author', type: 'text', required: true, placeholder: 'Author name' },
    { key: 'isbn', label: 'ISBN', type: 'text', required: true, placeholder: 'ISBN / unique code' },
    { key: 'category', label: 'Category', type: 'text', required: false, placeholder: 'e.g. Technology' },
    { key: 'year', label: 'Publication Year', type: 'number', required: false, placeholder: '2024' },
    { key: 'available', label: 'Available Copies', type: 'number', required: true, placeholder: '1' }
  ],
  searchKeys: ['title', 'author', 'isbn', 'category']
};
