// Change this file to rename the application without editing the main code.
module.exports = {
  appName: 'Library Management System',
  shortName: 'LMS',
  tagline: 'A simple, adaptable record management project',
  port: process.env.PORT || 3000
};
