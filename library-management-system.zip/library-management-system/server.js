const express = require('express');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const appConfig = require('./config/app');
const entityConfig = require('./config/entities');
const app = express();
const PORT = appConfig.port;
const DATA_FILE = path.join(__dirname, 'data', 'books.json');

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));
const readRecords = () => JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
const writeRecords = (records) => fs.writeFileSync(DATA_FILE, JSON.stringify(records, null, 2));
const cleanRecord = (body) => {
  const record = {};
  for (const field of entityConfig.fields) {
    let value = body[field.key];
    if (field.type === 'number' && value !== '' && value != null) value = Number(value);
    if (field.required && (value === undefined || value === null || String(value).trim() === '')) {
      throw new Error(`${field.label} is required`);
    }
    if (value !== undefined) record[field.key] = value;
  }
  return record;
};

app.get('/api/config', (req, res) => res.json({ ...appConfig, ...entityConfig }));
app.get('/api/records', (req, res) => {
  const query = String(req.query.q || '').toLowerCase();
  let records = readRecords();
  if (query) records = records.filter(r => entityConfig.searchKeys.some(k => String(r[k] ?? '').toLowerCase().includes(query)));
  res.json(records);
});
app.get('/api/records/:id', (req, res) => {
  const record = readRecords().find(r => r.id === req.params.id);
  if (!record) return res.status(404).json({ error: 'Record not found' });
  res.json(record);
});
app.post('/api/records', (req, res) => {
  try {
    const record = cleanRecord(req.body);
    const records = readRecords();
    const uniqueKey = entityConfig.uniqueKey;
    const uniqueValue = uniqueKey ? record[uniqueKey] : null;
    if (uniqueValue && records.some(r => String(r[uniqueKey]) === String(uniqueValue))) return res.status(409).json({ error: `A record with this ${uniqueKey} already exists` });
    record.id = crypto.randomUUID();
    records.push(record); writeRecords(records);
    res.status(201).json(record);
  } catch (e) { res.status(400).json({ error: e.message }); }
});
app.put('/api/records/:id', (req, res) => {
  try {
    const records = readRecords();
    const index = records.findIndex(r => r.id === req.params.id);
    if (index < 0) return res.status(404).json({ error: 'Record not found' });
    records[index] = { ...records[index], ...cleanRecord(req.body), id: records[index].id };
    writeRecords(records); res.json(records[index]);
  } catch (e) { res.status(400).json({ error: e.message }); }
});
app.delete('/api/records/:id', (req, res) => {
  const records = readRecords();
  const next = records.filter(r => r.id !== req.params.id);
  if (next.length === records.length) return res.status(404).json({ error: 'Record not found' });
  writeRecords(next); res.json({ success: true });
});

// Small demonstration auth API for the RBAC practical. Replace demo credentials before real use.
const demoUsers = [
  { username: 'admin', password: 'Admin@123', role: 'admin' },
  { username: 'librarian', password: 'Librarian@123', role: 'editor' },
  { username: 'student', password: 'Student@123', role: 'viewer' }
];
const sessions = new Map();
app.post('/api/login', (req, res) => {
  const user = demoUsers.find(u => u.username === req.body.username && u.password === req.body.password);
  if (!user) return res.status(401).json({ error: 'Invalid username or password' });
  const token = crypto.randomBytes(24).toString('hex');
  sessions.set(token, { username: user.username, role: user.role });
  res.json({ token, username: user.username, role: user.role });
});
function requireRole(...roles) {
  return (req, res, next) => {
    const token = (req.headers.authorization || '').replace(/^Bearer\s+/i, '');
    const user = sessions.get(token);
    if (!user) return res.status(401).json({ error: 'Please log in first' });
    if (!roles.includes(user.role)) return res.status(403).json({ error: 'Your role cannot perform this action' });
    req.user = user; next();
  };
}
app.get('/api/admin/summary', requireRole('admin'), (req, res) => res.json({ message: 'Admin-only route', totalRecords: readRecords().length }));
app.get('/api/health', (req, res) => res.json({ status: 'ok' }));

app.listen(PORT, () => console.log(`${appConfig.appName} running at http://localhost:${PORT}`));
