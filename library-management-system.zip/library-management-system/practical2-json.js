const fs = require('fs');
const book = { title: 'Clean Code', author: 'Robert C. Martin', tags: ['software', 'programming'] };
console.log('JSON object:', book);
fs.writeFileSync('data/example.json', JSON.stringify(book, null, 2));
console.log('Read external JSON:', JSON.parse(fs.readFileSync('data/example.json', 'utf8')));
const shelves = [[{title:'Clean Code', shelf:'A1'}, {title:'Atomic Habits', shelf:'B2'}], [{title:'The Pragmatic Programmer', shelf:'A2'}]];
console.log('2D JSON array:', shelves);
console.log('Specific item shelves[0][1]:', shelves[0][1]);
